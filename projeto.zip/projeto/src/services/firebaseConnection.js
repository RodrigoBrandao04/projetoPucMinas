
import { initializeApp } from 'firebase/app'
import { getAuth } from 'firebase/auth'
import { getFirestore } from 'firebase/firestore'
import { getStorage } from 'firebase/storage';

const firebaseConfig = {

  apiKey: "AIzaSyDOBsVlptj_wrX7f04TiWY-UsrcXFYJViI",
  authDomain: "projeto-chamados-17256.firebaseapp.com",
  projectId: "projeto-chamados-17256",
  storageBucket: "projeto-chamados-17256.appspot.com",
  messagingSenderId: "324826432079",
  appId: "1:324826432079:web:7990604061463172f7203a",
  measurementId: "G-F0ZPPZNKSJ"
};


const firebaseApp = initializeApp(firebaseConfig);

const auth = getAuth(firebaseApp);
const db = getFirestore(firebaseApp);
const storage = getStorage(firebaseApp);

export { auth, db, storage };